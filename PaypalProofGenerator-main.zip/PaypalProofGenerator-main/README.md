# Fake Paypal Proof Generator

## HERE:
You can Open the link the generate <a href='#'>HERE</a>

## What is this?
It generates proof of paypal payment (example: You've sent 90.00 USD to destrotn@fake.com)
* <img src="https://github.com/DesTroTN/PaypalProofGenerator/blob/main/sc/1.PNG" border="0"></a>
<br> 

## How does it work?
1. Download the code and open index.html (go straight to this website link already ready )

2. Fill in the form

* <img src="https://github.com/DesTroTN/PaypalProofGenerator/blob/main/sc/2.PNG" border="0"></a>

You're done! All simple, easy

## Credits :
```
This Script is free to distribute, modify and use with the condition that credit is provided to the creator (@DesTroTN) and is not for commercial use.
Github : DesTroTN
Zone-h : DesTroTN
Facebook : DesTroTN
```
